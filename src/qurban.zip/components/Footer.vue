<template>
    <div>
        <!-- <footer id="sticky-footer" class="py-3 bg-dark text-white">
            <div class="container text-center">
            <small>Copyright &copy; Qurban MPD-MPR | di koding dengan <i class="fas fa-heart" style="color: red;"></i> di sekretariat MPR   </small>
            </div>
        </footer> -->
    </div>
</template>

<script>
    export default {
        name : 'Footer'
    }
</script>

<style>

</style>