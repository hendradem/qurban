<template>
  <div>
    <Header />
    <!-- <Whatsapporder />
    <Request /> -->
  </div>
</template>

<script>
import "@/vendor.js";
import Header from "@/components/Header.vue";
// import Whatsapporder from "@/components/Whatsapporder.vue";
// import Request from "@/components/Request.vue";

export default {
  name: "Home",
  components: {
    Header,
    // Whatsapporder,
    // Request,
  },
};
</script>
