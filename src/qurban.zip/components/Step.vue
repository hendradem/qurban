<template>
    <div class="step-container">
        <div class="qurbanHeading">
              <h3 class="choiceHeading pt-5"> Step-step pemesanan </h3>
              <p>
                Kami buat se sederhana mungkin dalam pemesanan hewan qurban. Silahkan lihat step dibawah ini
              </p>
        </div>
        <div class="container py-2 pb-5">
            <div class="row">
                <div class="col-md-3 mb-2">
                    <div class="card bg-transparent border-0">
                    <div class="card-body p-0">
                        <img width="800" class="img-fluid" src="../assets/images/step/step1.png" />
                    </div>
                    </div>
                </div>
                <div class="col-md-3 mb-2">
                    <div class="card bg-transparent border-0">
                    <div class="card-body p-0">
                        <img width="800" class="img-fluid" src="../assets/images/step/step2.png" />
                    </div>
                    </div>
                </div>
                <div class="col-md-3 mb-2">
                    <div class="card bg-transparent border-0">
                    <div class="card-body p-0">
                        <img width="800" class="img-fluid" src="../assets/images/step/step3.png" />
                    </div>
                    </div>
                </div>
                <div class="col-md-3 mb-2">
                    <div class="card bg-transparent border-0">
                    <div class="card-body p-0">
                        <img width="800" class="img-fluid" src="../assets/images/step/step4.png" />
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>


<script>
export default {
    name : 'Step'
}
</script>

<style scoped>
    .how-to {
        width: 100%;
        height: 400px;
    }
</style>