<template>
  <div class="container">
    <h2>Kambing</h2>
  </div>
</template>

<script>
export default {};
</script>
