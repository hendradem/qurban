<template>
  <div>
    <Header />
  </div>
</template>

<script>
import "@/vendor.js";
import Header from "@/components/Header.vue";

export default {
  name: "Home",
  components: {
    Header,
  },
};
</script>
